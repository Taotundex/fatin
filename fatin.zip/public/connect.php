<?php

$conn = mysqli_connect("localhost", "root", "", "fatin");

if (!$conn) {
    die("Connection failed : " . !$conn);
}else{

}


?>